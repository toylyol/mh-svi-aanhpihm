"MinorityHealthSVI_DataDictionary_2018.csv" is the MH SVI data dictionary.

"mh_svi_county_2018.csv" is the MH SVI data (county-level).

"CDC_SVI_2018_DD.xlsx" is the 2018 SVI data dictionary, and it was retrieved from GitHub (https://github.com/cymonegates/SVI_R_Script). 

"SVI2018_US.csv" is the US-wide 2018 SVI Census tract dataset.

""SVI2018_US_COUNTY.csv is US-wide 2018 SVI county dataset.